
Gitflow
=======

Features
--------
.. autowindowcmd:: sgit.git_extensions.git_flow.GitFlowFeatureStartCommand
.. autowindowcmd:: sgit.git_extensions.git_flow.GitFlowFeatureFinishCommand


Releases
--------
.. autowindowcmd:: sgit.git_extensions.git_flow.GitFlowReleaseStartCommand
.. autowindowcmd:: sgit.git_extensions.git_flow.GitFlowReleaseFinishCommand

Hotfixes
--------
.. autowindowcmd:: sgit.git_extensions.git_flow.GitFlowHotfixStartCommand
.. autowindowcmd:: sgit.git_extensions.git_flow.GitFlowHotfixFinishCommand
