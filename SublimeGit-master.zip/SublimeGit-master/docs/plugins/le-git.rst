
Le-git
======

Branches
--------
.. autowindowcmd:: sgit.git_extensions.legit.LegitSwitchCommand
.. autowindowcmd:: sgit.git_extensions.legit.LegitBranchesCommand
.. autowindowcmd:: sgit.git_extensions.legit.LegitSproutCommand
.. autowindowcmd:: sgit.git_extensions.legit.LegitHarvestCommand
.. autowindowcmd:: sgit.git_extensions.legit.LegitGraftCommand

Remotes
-------
.. autowindowcmd:: sgit.git_extensions.legit.LegitSyncCommand
.. autowindowcmd:: sgit.git_extensions.legit.LegitPublishCommand
.. autowindowcmd:: sgit.git_extensions.legit.LegitUnpublishCommand
