Plugins
=======

SublimeGit comes with plugins for Le-git and git-flow.

.. toctree::
   :maxdepth: 3

   plugins/le-git
   plugins/gitflow
