<?php 

class IndexController extends \Think\Controller {
	public function index(){
		$this->display('index');
	}
}
