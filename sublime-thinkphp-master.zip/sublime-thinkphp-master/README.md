# sublime-thinkphp
thinkphp 的 sublime 快速补全插件

### controller

![controller](./example/images/controller.gif)


### model

![model](./example/images/model.gif)


### template

![template](./example/images/template.gif)
